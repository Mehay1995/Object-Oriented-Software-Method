public class icanMute implements QuackBehavior{
  
  public void quack() {
    System.out.println("No sound"); 
  }
  
  
}