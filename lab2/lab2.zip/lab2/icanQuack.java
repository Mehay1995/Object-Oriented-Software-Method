public class icanQuack implements QuackBehavior{
  
  public void quack() {
    System.out.println("Quack"); 
  }
  
  
}