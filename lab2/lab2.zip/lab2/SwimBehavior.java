public interface SwimBehavior{
  public void swim();
}