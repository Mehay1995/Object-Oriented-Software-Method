package hw4;

public class singletonDemo {

	public static void main(String[] args) {
		SingleRandom object = SingleRandom.getInstance();
		
		
		object.showRandom();
		
	}

}
