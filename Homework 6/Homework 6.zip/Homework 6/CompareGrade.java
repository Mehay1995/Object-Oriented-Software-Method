public interface CompareGrade<T> { 
  int boobear(T other);
}