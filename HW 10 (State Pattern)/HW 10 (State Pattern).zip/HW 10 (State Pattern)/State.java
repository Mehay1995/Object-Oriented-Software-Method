
public interface State {
	
}
