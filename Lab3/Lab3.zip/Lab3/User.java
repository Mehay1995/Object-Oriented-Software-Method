import java.util.*;

  public class User extends Observerable implements Observer {
  String Name;
  
  public User(String name){
    this.name = name;
  }
  
  }
  